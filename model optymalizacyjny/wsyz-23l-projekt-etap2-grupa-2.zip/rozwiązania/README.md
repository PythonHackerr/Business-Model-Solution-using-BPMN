# Legenda rozwązań:
Uwaga: Kolumny zawierające same zera zostały ukryte.

## Ogólne informacje
Funkcja celu, czyli minimalny całkowity koszt transportu w roku, to:

`401203.81 PLN`

### Testy poprawności modelu:
Suma wszystkich dostaw do sklepow

`2348.134 t`

Suma wszystkich dostaw do magazynów

`2348.134 t`

Suma wszystkich prognoz *(liczba ta jest mniejsza od powyższych, gdyż w sklepach pozostało 10% zapasów po ostatnim tygodniu)*

`2343.622 t`

## Pliki z rozwiązaniami

Plik `model optymalizacyjny/rozwiązania/rok_trans_warz_magazyny.txt`
> zawiera informację o tym, ile ton do danego magazynu należy przetransportować danego warzywa od określonego producenta

Plik `model optymalizacyjny/rozwiązania/tyg_trans_warz_sklep.txt`
> zawiera informację o tym, ile ton do danego sklepu należy przetransportować pewnego warzywa z pewnego magazynu centrali w danym tygodniu

Na przykład:
```
transport_do_sklepow_tyg [*,Piaseczno,Buraki,*] (tr)
:  ArabicGroceryShop DobryWarzywniak Krzesak UKermita UPanaWojtka    :=
1         0.000            1.114       1.578   1.032      0.000
[ ... ]
```
Oznacza że z magazynu *Piaseczno*, należy przetransportować pewną ilość ton *Buraków* do jakiegoś z powyższych sklepów w danym tygodniu.

### Test dla wybranego sklepu - "U Karolci"
Plik `model optymalizacyjny/rozwiązania/karolcia_dostawy.txt`
> zawiera informację o tym z którego magazynu oraz ile ton poszczególnego warzywa zostanie przetransportowane do warzywniaka "U Karolci" w danym tygodniu. W tym wypadku użyty został tylko jeden magazyn (kolumny zerowe są ukryte).

Plik `model optymalizacyjny/rozwiązania/karolcia_prognozy.txt`
> zawiera prognozy dla sklepu "U Karloci" (dane wygenerowane losowo)

Plik `model optymalizacyjny/rozwiązania/karolcia_stan.txt`
> zawiera stan (ilość ton) na koniec każdego tygodnia każdego z warzyw w magazynie przysklepowym "U Karolci"